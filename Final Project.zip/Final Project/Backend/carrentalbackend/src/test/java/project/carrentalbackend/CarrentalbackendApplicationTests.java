package project.carrentalbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrentalbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
