package carrental.support;

public class Help {
	
	/*
	 * 
	 * 
	 * 
	 * 
	delimeter //
	CREATE TRIGGER booking_AFTER_DELETE AFTER DELETE ON booking FOR EACH ROW 
	BEGIN

    insert into cancel values (old.booking_id,old.ammt,old.rental_date,old.returndate,old.car_id,old.user_user_no);

     END //
			
	
	*
	*
	*
	*
	*
	*
	*/
}
