import React from "react";

function NoPage() {
  return (
    <div className="NoPage justify-centre">
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <h1>
        {" "}
        <b>Page Not Found</b>
      </h1>
      <br />
      <br />
      <a href="/">
        <h3>Click Here</h3>
      </a>
    </div>
  );
}

export default NoPage;
